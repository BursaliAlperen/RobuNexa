"use strict";
/*
 * Real-Electron self test. Run:  "Roblox Forge AI.exe" --selftest   (or `npx electron . --selftest`)
 * Uses webContents.sendInputEvent => genuine mouse events through Chromium's input pipeline
 * (not synthetic dispatchEvent), so invisible overlays / pointer-events problems are caught.
 * Writes a JSON report and exits 0 (all passed) / 1 (failures) / 2 (timeout) / 3 (harness error).
 * Only loaded when --selftest is present; never runs in normal use.
 */
const fs = require("node:fs");
const path = require("node:path");

function run({ win, log, app, APP_URL }) {
  const wc = win.webContents;
  const results = [];
  const consoleErrors = [];
  const ipcErrors = [];
  let crashed = null;
  const rec = (name, pass, detail = "") => { results.push({ name, pass: !!pass, detail: String(detail) }); log("SELFTEST " + (pass ? "PASS " : "FAIL ") + name + (detail ? " :: " + detail : "")); };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const ev = (code) => wc.executeJavaScript(code, true);

  wc.on("console-message", (_e, level, msg) => { if (level >= 3) consoleErrors.push(msg); });
  wc.on("render-process-gone", (_e, d) => { crashed = d; });
  const killer = setTimeout(() => { log("SELFTEST TIMEOUT"); finish(2); }, 90000);

  function finish(code) {
    clearTimeout(killer);
    const failed = results.filter((r) => !r.pass).length;
    const report = { version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, platform: process.platform, url: wc.getURL(), passed: results.length - failed, failed, consoleErrors, crashed, results };
    const out = process.env.RFA_SELFTEST_REPORT || path.join(app.getPath("userData"), "selftest-report.json");
    try { fs.writeFileSync(out, JSON.stringify(report, null, 2)); } catch (e) { log("SELFTEST REPORT WRITE " + e.message); }
    try { console.log("SELFTEST " + (failed ? "FAILED" : "OK") + " passed=" + report.passed + " failed=" + failed + " report=" + out); } catch { /* no console in GUI exe */ }
    app.exit(code === 0 && failed ? 1 : code);
  }

  async function center(sel) {
    return ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const r=e.getBoundingClientRect();return {x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)}})()`);
  }
  async function realClick(sel) {
    const c = await center(sel);
    if (!c) throw new Error("not found: " + sel);
    wc.sendInputEvent({ type: "mouseMove", x: c.x, y: c.y });
    wc.sendInputEvent({ type: "mouseDown", x: c.x, y: c.y, button: "left", clickCount: 1 });
    wc.sendInputEvent({ type: "mouseUp", x: c.x, y: c.y, button: "left", clickCount: 1 });
    await sleep(80);
  }
  const state = () => ev(`({active:[...document.querySelectorAll('[data-nav].active')].map(b=>b.dataset.nav),page:document.body.dataset.page||'',h1:(document.querySelector('#content h1')||{}).textContent||''})`);

  (async () => {
    try {
      await new Promise((res) => { if (!wc.isLoading()) res(); else wc.once("did-finish-load", res); });
      win.show(); win.focus(); await sleep(600);

      rec("loads local desktop.html via file://", wc.getURL() === APP_URL && wc.getURL().startsWith("file://"), wc.getURL());
      rec("no http(s) page loaded", !/^https?:/i.test(wc.getURL()));

      const info = await ev(`window.robloxForgeDesktop ? window.robloxForgeDesktop.appInfo() : null`);
      const pkg = JSON.parse(fs.readFileSync(path.join(app.getAppPath(), "package.json"), "utf8"));
      rec("preload exposes API + IPC works", !!info && info.version === pkg.version, info ? "app=" + info.version + " pkg=" + pkg.version : "no API");

      const navs = await ev(`[...document.querySelectorAll('[data-nav]')].map(b=>b.dataset.nav)`);
      rec("6 nav buttons present", navs.length === 6, navs.join(","));
      rec("dashboard rendered on start", (await state()).h1.length > 0 && (await state()).active.join() === "dashboard");

      // overlay / pointer-events: element at each button's centre must be the button itself
      for (const n of navs) {
        const hit = await ev(`(()=>{const b=document.querySelector('[data-nav="${n}"]');const r=b.getBoundingClientRect();const t=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return !!t&&(t===b||b.contains(t))})()`);
        rec("no overlay above nav:" + n, hit);
      }

      // real clicks, in order, with exactly-one-active check
      const expectH1 = {};
      for (const n of ["chat", "studio", "plan", "logs", "keys", "dashboard"]) {
        await realClick('[data-nav="' + n + '"]');
        const s = await state();
        rec("real click -> " + n, s.active.length === 1 && s.active[0] === n && s.page === n && s.h1.length > 0, JSON.stringify(s));
        expectH1[n] = s.h1;
      }
      const uniq = new Set(Object.values(expectH1));
      rec("each page has distinct content", uniq.size >= 5, [...uniq].join(" | "));

      // rapid click storm
      const seq = ["keys", "chat", "logs", "dashboard", "plan", "studio", "keys", "dashboard", "chat", "chat", "chat", "logs", "dashboard"];
      for (const n of seq) {
        const c = await center('[data-nav="' + n + '"]');
        wc.sendInputEvent({ type: "mouseMove", x: c.x, y: c.y });
        wc.sendInputEvent({ type: "mouseDown", x: c.x, y: c.y, button: "left", clickCount: 1 });
        wc.sendInputEvent({ type: "mouseUp", x: c.x, y: c.y, button: "left", clickCount: 1 });
      }
      await sleep(400);
      const last = await state();
      rec("rapid clicks: final state consistent", last.active.length === 1 && last.active[0] === "dashboard" && last.page === "dashboard", JSON.stringify(last));

      // Auto Development toggle (button + checkbox), on dashboard
      await ev(`localStorage.removeItem('autoDev')`);
      await realClick("#autoToggle");
      rec("auto toggle button -> ON", (await ev(`localStorage.getItem('autoDev')`)) === "1" && /ON/.test(await ev(`document.getElementById('autoToggle').textContent`)));
      await realClick(".autoSwitch");
      await sleep(500);
      rec("auto switch checkbox -> OFF", (await ev(`localStorage.getItem('autoDev')`)) === "0" && (await ev(`document.getElementById('chatAuto').checked`)) === false);
      await ev(`localStorage.removeItem('autoDev')`);

      // navigation lock: renderer must not be able to leave desktop.html
      await ev(`location.href='https://example.com/'`).catch(() => {});
      await sleep(1200);
      rec("navigation to website is blocked", wc.getURL() === APP_URL, wc.getURL());

      rec("no renderer crash", !crashed, JSON.stringify(crashed));
      rec("no console errors", consoleErrors.length === 0, consoleErrors.join(" | "));
      finish(0);
    } catch (e) {
      log("SELFTEST HARNESS ERROR " + (e && e.stack));
      rec("harness", false, e && e.message);
      finish(3);
    }
  })();
}

module.exports = { run };
