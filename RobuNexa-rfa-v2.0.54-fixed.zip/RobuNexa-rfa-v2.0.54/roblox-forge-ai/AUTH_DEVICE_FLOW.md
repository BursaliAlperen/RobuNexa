# Website login -> EXE (device authorization, RFC 8628 + PKCE)

Client: `device-auth.cjs` (done, tested). **Server: not in this repo — must be implemented on roblox-forge-ai.hatchable.site.**
`tests/mock-forge-server.mjs` is a working reference implementation of every endpoint below.

## Flow
1. EXE: generates random `code_verifier`, sends only `SHA256(verifier)` (`code_challenge`) to `POST /api/device/start`.
2. Server returns `device_code` (256-bit, secret), `user_code` (`XXXX-XXXX`, non-secret), `verification_uri_complete`
   (`https://roblox-forge-ai.hatchable.site/device?user_code=XXXX-XXXX`), `expires_in`, `interval`.
3. EXE opens that URL in the system browser. **Only `user_code` is ever in a URL.**
4. User logs in on the website normally (existing session), sees "Approve device <name>? code XXXX-XXXX" and clicks Approve
   (CSRF-protected POST, requires the logged-in session). No approve on GET.
5. EXE polls `POST /api/device/token {device_code, code_verifier}` every `interval`s.
6. On approval the server returns `{access_token}` **once** in the response body, then deletes the record.
7. EXE stores it with Electron `safeStorage` (DPAPI on Windows); it never reaches the renderer / localStorage / URL.

## Endpoints
| Endpoint | Body | Responses |
|---|---|---|
| `POST /api/device/start` | `client_id, code_challenge, code_challenge_method="S256", device_name, app_version, platform` | 200 `{device_code,user_code,verification_uri,verification_uri_complete,expires_in,interval}` |
| `POST /api/device/token` | `device_code, code_verifier, client_id` | 200 `{access_token,token_type:"bearer",account}` / 400 `authorization_pending` `slow_down` `access_denied` `expired_token` `invalid_grant` |
| `POST /api/device/revoke` | `Authorization: Bearer <token>` | 200 |
| Website page `GET /device` | `?user_code=` (prefilled, editable) | login-gated approve/deny page |

## Server requirements (security checklist)
- `device_code`: >=256-bit random; `user_code`: 8 chars from an unambiguous alphabet, single use, TTL <=10 min, rate-limit attempts per IP/account.
- Verify `base64url(SHA256(code_verifier)) == code_challenge` on every poll (constant-time). Reject otherwise (`invalid_grant`).
- Deliver `access_token` exactly once; delete the device record afterwards. Store only a hash of the token server-side.
- Token = device-scoped, revocable, listed in the user's account ("Devices"). The existing bridge sends it as `x-forge-key`,
  so the server must accept it there (and in `Authorization: Bearer`).
- Approve page must show device name + user_code and require an explicit click; deny -> `access_denied`.
- `verification_uri_complete` must be on the Forge origin under `/device` (the client rejects anything else).
- `POST /api/keys/create` currently mints a key with **no authentication** — should be removed or gated once this flow ships.

## Testing
`node tests/auth.test.mjs` (client vs. mock server), `node tests/main.test.cjs` (main-process logic vs. stub electron),
`node tests/ui.test.mjs` (real Chromium, needs `playwright`), and in CI the real-Electron `--selftest`.
