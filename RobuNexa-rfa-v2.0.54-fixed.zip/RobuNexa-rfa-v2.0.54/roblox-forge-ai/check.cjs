"use strict";
// Pre-build static checks. Fails the build on the class of bug that shipped in v2.0.54:
// a syntax error in the renderer script silently killed every handler.
const fs=require("node:fs"),path=require("node:path"),cp=require("node:child_process");
const root=__dirname,errs=[];
const pkg=JSON.parse(fs.readFileSync(path.join(root,"package.json"),"utf8"));
const files=pkg.build.files;
for(const f of files){if(!fs.existsSync(path.join(root,f)))errs.push("package.json build.files lists missing file: "+f)}
for(const f of files.filter(f=>/\.(c?js|mjs)$/.test(f))){
  const r=cp.spawnSync(process.execPath,["--check",path.join(root,f)],{encoding:"utf8"});
  if(r.status!==0)errs.push("SYNTAX ERROR in "+f+":\n"+(r.stderr||"").split("\n").slice(0,6).map(l=>l.slice(0,160)).join("\n"));
}
for(const f of ["build-exe.mjs","build-bundle.mjs","check.cjs"]){const r=cp.spawnSync(process.execPath,["--check",path.join(root,f)],{encoding:"utf8"});if(r.status!==0)errs.push("SYNTAX ERROR in "+f)}
// every local require() of a packaged file must be packaged
for(const f of files.filter(f=>/\.cjs$/.test(f))){
  const src=fs.readFileSync(path.join(root,f),"utf8");
  for(const m of src.matchAll(/require\("\.\/([^"]+)"\)/g))if(!files.includes(m[1]))errs.push(f+" requires ./"+m[1]+" which is not in build.files");
}
const html=fs.readFileSync(path.join(root,"desktop.html"),"utf8");
const scripts=[...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)];
if(!scripts.length)errs.push("desktop.html has no <script>");
for(const [,attrs,body] of scripts){
  const src=(attrs.match(/src="([^"]+)"/)||[])[1];
  if(src){if(/^[a-z]+:/i.test(src))errs.push("desktop.html loads remote script: "+src);else if(!files.includes(src))errs.push("desktop.html script "+src+" not in build.files")}
  else if(body.trim()){const t=path.join(require("node:os").tmpdir(),"rfa-inline-check.js");fs.writeFileSync(t,body);const r=cp.spawnSync(process.execPath,["--check",t],{encoding:"utf8"});if(r.status!==0)errs.push("SYNTAX ERROR in desktop.html inline script:\n"+r.stderr.split("\n").slice(0,6).map(l=>l.slice(0,160)).join("\n"))}
}
if(!/http-equiv="Content-Security-Policy"/.test(html))errs.push("desktop.html has no CSP meta");
if(/<meta[^>]+http-equiv="refresh"/i.test(html))errs.push("desktop.html has meta refresh (redirect)");
if(/<(iframe|link[^>]+rel="stylesheet")[^>]+(src|href)="https?:/i.test(html))errs.push("desktop.html loads remote iframe/stylesheet");
if(errs.length){console.error("CHECK FAILED\n - "+errs.join("\n - "));process.exit(1)}
console.log("check OK: "+files.length+" packaged files, version "+pkg.version);
