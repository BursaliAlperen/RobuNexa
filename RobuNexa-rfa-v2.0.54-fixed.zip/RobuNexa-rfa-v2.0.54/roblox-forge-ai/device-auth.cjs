"use strict";
/*
 * One-time device authorization for the desktop app (RFC 8628 style, hardened with PKCE).
 *
 * Security properties:
 *  - No password, no API key and no token ever appears in a URL. The browser only receives a
 *    short, single-use, non-secret `user_code` (useless without the device_code + verifier
 *    that never leave this process <-> server HTTPS channel).
 *  - PKCE (S256): the server binds the login to a random verifier that only this process knows,
 *    so an intercepted device_code cannot be redeemed by anyone else.
 *  - The access token is delivered exactly once, in an HTTPS POST response body, and is stored
 *    only through `store` (Electron safeStorage in production). It is never sent to the renderer.
 *  - The URL opened in the browser is validated against the Forge origin (no open redirect).
 *
 * Server contract: see AUTH_DEVICE_FLOW.md
 */
const crypto = require("node:crypto");

const b64url = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const sleepDefault = (ms, signal) => new Promise((resolve) => {
  const t = setTimeout(resolve, ms);
  if (signal) signal.addEventListener("abort", () => { clearTimeout(t); resolve(); }, { once: true });
});

function createDeviceAuth(opts) {
  const {
    baseUrl,
    store,                                   // { load():string|null, save(token):boolean, clear():void }
    openExternal,                            // (url) => Promise|void
    onState = () => {},                      // ({state, detail, user_code?, expires_at?}) => void
    fetchImpl = globalThis.fetch,
    sleep = sleepDefault,
    now = () => Date.now(),
    deviceName = "Roblox Forge AI Desktop",
    appVersion = "0.0.0",
    platform = process.platform,
    clientId = "roblox-forge-desktop",
    requestTimeoutMs = 15000,
  } = opts;
  if (!baseUrl) throw new Error("baseUrl required");
  const origin = new URL(baseUrl).origin;

  let state = "signed_out";                  // signed_out | pending | approved | denied | expired | error
  let detail = "";
  let userCode = null;
  let expiresAt = null;
  let abort = null;                          // AbortController for the running flow
  let token = null;                          // in-memory copy (main process only)

  function set(next, d = "", extra = {}) {
    state = next; detail = d;
    try { onState({ state, detail, user_code: userCode, expires_at: expiresAt, ...extra }); } catch { /* UI must never break auth */ }
  }

  async function post(path, body, extraHeaders = {}, signal) {
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), requestTimeoutMs);
    if (signal) signal.addEventListener("abort", () => c.abort(), { once: true });
    try {
      const r = await fetchImpl(origin + path, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...extraHeaders },
        body: JSON.stringify(body || {}),
        signal: c.signal,
        redirect: "error",                   // never follow redirects with credentials in flight
      });
      let data = {};
      try { data = await r.json(); } catch { /* non-JSON body */ }
      return { status: r.status, ok: r.ok, data };
    } finally { clearTimeout(t); }
  }

  function safeVerificationUrl(u) {
    let url;
    try { url = new URL(u); } catch { throw new Error("Sunucu geçersiz doğrulama adresi döndürdü."); }
    if (url.origin !== origin) throw new Error("Doğrulama adresi Forge sitesine ait değil; reddedildi.");
    if (!url.pathname.startsWith("/device")) throw new Error("Beklenmeyen doğrulama yolu; reddedildi.");
    if (/token|key|password|secret|verifier|device_code/i.test(url.search)) throw new Error("Doğrulama adresi hassas parametre içeriyor; reddedildi.");
    return url.href;
  }

  async function start() {
    if (abort) abort.abort();                // restart cleanly
    abort = new AbortController();
    const mine = abort;
    const verifier = b64url(crypto.randomBytes(48));
    const challenge = b64url(crypto.createHash("sha256").update(verifier).digest());
    userCode = null; expiresAt = null;
    set("pending", "Kod isteniyor...");
    let init;
    try {
      init = await post("/api/device/start", {
        client_id: clientId, code_challenge: challenge, code_challenge_method: "S256",
        device_name: deviceName, app_version: appVersion, platform,
      }, {}, mine.signal);
    } catch (e) { set("error", "Forge sunucusuna ulaşılamadı: " + (e && e.message)); return { ok: false, error: "network" }; }
    if (init.status === 404 || init.status === 405) {
      set("error", "Sunucuda cihaz yetkilendirme uçları (/api/device/*) henüz yok. AUTH_DEVICE_FLOW.md'ye bakın.");
      return { ok: false, error: "server_unsupported" };
    }
    const d = init.data || {};
    if (!init.ok || !d.device_code || !d.user_code || !d.verification_uri_complete) {
      set("error", d.error_description || d.error || ("Sunucu hatası " + init.status));
      return { ok: false, error: "bad_response" };
    }
    let url;
    try { url = safeVerificationUrl(d.verification_uri_complete); } catch (e) { set("error", e.message); return { ok: false, error: "unsafe_url" }; }
    userCode = String(d.user_code);
    expiresAt = now() + Math.max(30, Number(d.expires_in) || 600) * 1000;
    let interval = Math.max(2, Number(d.interval) || 5);
    set("pending", "Tarayıcıda giriş yapıp cihazı onaylayın.");
    try { await openExternal(url); } catch (e) { set("pending", "Tarayıcı açılamadı; " + origin + "/device adresine gidip kodu girin."); }

    poll(d.device_code, verifier, interval, mine).catch((e) => { if (!mine.signal.aborted) set("error", String(e && e.message || e)); });
    return { ok: true, user_code: userCode, expires_at: expiresAt, verification_uri: origin + "/device" };
  }

  async function poll(deviceCode, verifier, interval, mine) {
    while (!mine.signal.aborted) {
      await sleep(interval * 1000, mine.signal);
      if (mine.signal.aborted) return;
      if (now() >= expiresAt) { set("expired", "Kodun süresi doldu. Yeniden deneyin."); return; }
      let r;
      try { r = await post("/api/device/token", { device_code: deviceCode, code_verifier: verifier, client_id: clientId }, {}, mine.signal); }
      catch (e) { if (mine.signal.aborted) return; continue; }            // transient network error: keep polling
      const d = r.data || {};
      if (r.ok && d.access_token) {
        const saved = store.save(String(d.access_token));
        token = String(d.access_token);
        userCode = null;
        set("approved", saved ? "Giriş başarılı." : "Giriş başarılı (güvenli depolama yok: token yalnızca bellekte).", { account: d.account || null, persisted: !!saved });
        return;
      }
      switch (d.error) {
        case "authorization_pending": break;
        case "slow_down": interval += 5; break;
        case "access_denied": set("denied", "İstek web sitesinde reddedildi."); return;
        case "expired_token": set("expired", "Kodun süresi doldu. Yeniden deneyin."); return;
        default:
          if (r.status >= 500) break;                                     // server hiccup: keep polling
          set("error", d.error_description || d.error || ("Beklenmeyen yanıt " + r.status)); return;
      }
    }
  }

  function cancel() { if (abort) abort.abort(); abort = null; userCode = null; expiresAt = null; set(token || store.load() ? "approved" : "signed_out", "İptal edildi."); return { ok: true }; }

  async function logout() {
    if (abort) abort.abort(); abort = null;
    const t = token || store.load();
    token = null; userCode = null; expiresAt = null;
    store.clear();
    if (t) { try { await post("/api/device/revoke", {}, { Authorization: "Bearer " + t }); } catch { /* best effort; server also expires tokens */ } }
    set("signed_out", "Çıkış yapıldı.");
    return { ok: true };
  }

  function getToken() { return token || (token = store.load()); }
  function status() { return { state: token || store.load() ? (state === "pending" ? "pending" : "approved") : state, detail, user_code: userCode, expires_at: expiresAt, signed_in: !!(token || store.load()) }; }

  return { start, cancel, logout, getToken, status, _b64url: b64url };
}

module.exports = { createDeviceAuth };
