import { createRequire } from 'node:module';
import crypto from 'node:crypto';
import { createMockForge } from './mock-forge-server.mjs';
const { createDeviceAuth } = createRequire(import.meta.url)('../device-auth.cjs');
const results = []; const rec = (n, ok, d = '') => { results.push(ok); console.log((ok ? 'PASS ' : 'FAIL ') + n + (d ? '  :: ' + String(d).slice(0, 200) : '')); };
const wait = async (f, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await f()) return true; await new Promise(r => setTimeout(r, 10)); } return false; };
const memStore = () => { let v = null; return { load: () => v, save: t => { v = t; return true; }, clear: () => { v = null; }, get v() { return v; } }; };
const fastSleep = (ms, sig) => new Promise(r => { const t = setTimeout(r, 15); sig && sig.addEventListener('abort', () => { clearTimeout(t); r(); }, { once: true }); });
async function mk(opts = {}, srvOpts = {}) {
  const forge = createMockForge(srvOpts); const base = await forge.listen(); const store = memStore(); const opened = [], states = [];
  const auth = createDeviceAuth({ baseUrl: base, store, sleep: fastSleep, openExternal: u => { opened.push(u); }, onState: s => states.push(s), ...opts });
  return { forge, base, store, opened, states, auth };
}

// 1. happy path
{ const t = await mk(); const r = await t.auth.start();
  rec('start ok, returns user_code', r.ok && /^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(r.user_code), r.user_code);
  rec('browser opened once, on Forge /device', t.opened.length === 1 && new URL(t.opened[0]).pathname === '/device', t.opened[0]);
  const u = new URL(t.opened[0]); const startReq = t.forge.log.find(l => l.url === '/api/device/start');
  const secrets = [startReq && 'x', ...[...t.forge.devices.keys()]];
  rec('URL carries ONLY user_code (no device_code/token/verifier/key/password)', [...u.searchParams.keys()].join() === 'user_code' && !secrets.some(s => s && t.opened[0].includes(s)) && !/token|key|pass|verifier|device_code/i.test(u.search), u.search);
  rec('PKCE challenge sent, verifier never sent at start', startReq.body.code_challenge_method === 'S256' && !('code_verifier' in startReq.body));
  await new Promise(r => setTimeout(r, 80));
  rec('still pending before approval; no token stored', t.auth.status().state === 'pending' && t.store.v === null);
  t.forge.approve(r.user_code);
  rec('after website approval -> approved', await wait(() => t.auth.status().state === 'approved'), t.auth.status().state);
  rec('token stored via store (not in state events)', !!t.store.v && t.store.v.startsWith('fdt_') && !JSON.stringify(t.states).includes(t.store.v));
  rec('token never appears in any request URL', t.forge.log.every(l => !l.url.includes(t.store.v)));
  rec('device_code never appears in any URL', t.forge.log.every(l => !/device_code=/.test(l.url)));
  const redeemedAgain = await fetch(t.base + '/api/device/token', { method: 'POST', body: JSON.stringify({ device_code: 'x' }) }); rec('unknown/used device_code rejected', redeemedAgain.status === 400);
  const before = t.forge.log.filter(l => l.url === '/api/device/token').length; await new Promise(r => setTimeout(r, 100));
  rec('polling stops after success', t.forge.log.filter(l => l.url === '/api/device/token').length === before);
  // logout revokes
  const tok = t.store.v; await t.auth.logout();
  const rv = t.forge.log.find(l => l.url === '/api/device/revoke');
  rec('logout: revoke sent as Authorization header (not URL/body)', rv && rv.auth === 'Bearer ' + tok && !JSON.stringify(rv.body).includes(tok));
  rec('logout: store cleared, server token gone', t.store.v === null && !t.forge.tokens.has(tok) && t.auth.status().state === 'signed_out');
  await t.forge.close(); }

// 2. PKCE: stolen device_code is useless without verifier
{ const t = await mk(); const r = await t.auth.start(); const dc = [...t.forge.devices.keys()][0]; t.forge.approve(r.user_code);
  const stolen = await fetch(t.base + '/api/device/token', { method: 'POST', body: JSON.stringify({ device_code: dc, code_verifier: 'attacker-guess' }) }); const j = await stolen.json();
  rec('PKCE: attacker with device_code but wrong verifier gets no token', stolen.status === 400 && !j.access_token, j.error);
  await t.auth.cancel(); await t.forge.close(); }

// 3. denied / expired / slow_down / cancel
{ const t = await mk(); const r = await t.auth.start(); t.forge.deny(r.user_code); rec('denied on website -> denied state, no token', await wait(() => t.auth.status().state === 'denied') && !t.store.v); await t.forge.close(); }
{ const t = await mk(); const r = await t.auth.start(); t.forge.expire(r.user_code); rec('server expired_token -> expired state', await wait(() => t.auth.status().state === 'expired')); await t.forge.close(); }
{ let clock = Date.now(); const t = await mk({ now: () => clock }); await t.auth.start(); clock += 11 * 60 * 1000; rec('client-side expiry after expires_in', await wait(() => t.auth.status().state === 'expired')); await t.forge.close(); }
{ const t = await mk(); t.forge.slowDownNext(); const r = await t.auth.start(); await new Promise(r => setTimeout(r, 120)); t.forge.approve(r.user_code); rec('slow_down tolerated, still completes', await wait(() => t.auth.status().state === 'approved')); await t.forge.close(); }
{ const t = await mk(); await t.auth.start(); await t.auth.cancel(); const n = t.forge.log.filter(l => l.url === '/api/device/token').length; await new Promise(r => setTimeout(r, 120));
  rec('cancel stops polling', t.forge.log.filter(l => l.url === '/api/device/token').length <= n + 1 && t.auth.status().state === 'signed_out'); await t.forge.close(); }
{ const t = await mk(); const a = await t.auth.start(); const b = await t.auth.start(); rec('restart issues a new code (old flow aborted)', a.user_code !== b.user_code); await t.auth.cancel(); await t.forge.close(); }

// 4. hostile / unsupported servers
{ const t = await mk({}, { evilUrl: true }); const r = await t.auth.start(); rec('verification URL on foreign origin is rejected; browser NOT opened', !r.ok && r.error === 'unsafe_url' && t.opened.length === 0, t.auth.status().detail); await t.forge.close(); }
{ const t = await mk({}, { unsupported: true }); const r = await t.auth.start(); rec('server without /api/device/* -> clear message, no crash', !r.ok && r.error === 'server_unsupported' && /AUTH_DEVICE_FLOW/.test(t.auth.status().detail)); await t.forge.close(); }
{ const t = await mk({ fetchImpl: async () => { throw new Error('ECONNREFUSED'); } }); const r = await t.auth.start(); rec('network down -> error state, no crash', !r.ok && t.auth.status().state === 'error'); await t.forge.close(); }
{ const t = await mk({ openExternal: () => { throw new Error('no browser'); } }); const r = await t.auth.start(); rec('browser open failure -> still pending with manual instructions', r.ok && /device/.test(t.auth.status().detail)); await t.auth.cancel(); await t.forge.close(); }
{ const t = await mk({ store: { load: () => null, save: () => false, clear() {} } }); const r = await t.auth.start(); t.forge.approve(r.user_code); await wait(() => t.auth.status().state === 'approved');
  rec('no safeStorage -> token kept in memory only, user told', /bellek/.test(t.states.at(-1).detail) && !!t.auth.getToken()); await t.forge.close(); }
{ const forgeUrlOk = (() => { try { createDeviceAuth({ baseUrl: '' , store: memStore(), openExternal() {} }); return false; } catch { return true; } })(); rec('baseUrl required', forgeUrlOk); }
const bad = results.filter(x => !x).length; console.log(`\n${results.length - bad}/${results.length} passed`); process.exit(bad ? 1 : 0);
