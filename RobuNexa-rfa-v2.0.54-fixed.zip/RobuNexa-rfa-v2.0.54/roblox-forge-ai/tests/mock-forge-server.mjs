// Reference implementation of the server side of AUTH_DEVICE_FLOW.md (in-memory). Also used by auth.test.mjs.
import http from 'node:http';
import crypto from 'node:crypto';
const b64url = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
export function createMockForge({ evilUrl = false, unsupported = false } = {}) {
  const devices = new Map(), byUser = new Map(), tokens = new Map(), log = [];
  let port = 0, slowDownOnce = false;
  const srv = http.createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    let body = {}; try { body = JSON.parse(Buffer.concat(chunks).toString() || '{}'); } catch {}
    log.push({ method: req.method, url: req.url, auth: req.headers.authorization || null, body });
    const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
    if (unsupported) return send(404, { error: 'not_found' });
    if (req.method === 'POST' && req.url === '/api/device/start') {
      if (body.code_challenge_method !== 'S256' || !body.code_challenge) return send(400, { error: 'invalid_request' });
      const device_code = b64url(crypto.randomBytes(32));
      const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; const raw = Array.from({ length: 8 }, () => A[crypto.randomInt(A.length)]).join(''); const user_code = raw.slice(0, 4) + '-' + raw.slice(4);
      devices.set(device_code, { user_code, challenge: body.code_challenge, status: 'pending', created: Date.now(), name: body.device_name });
      byUser.set(user_code, device_code);
      const origin = `http://127.0.0.1:${port}`;
      return send(200, { device_code, user_code, verification_uri: origin + '/device', verification_uri_complete: (evilUrl ? 'https://evil.example' : origin) + '/device?user_code=' + user_code, expires_in: 600, interval: 5 });
    }
    if (req.method === 'POST' && req.url === '/api/device/token') {
      const d = devices.get(body.device_code);
      if (!d) return send(400, { error: 'expired_token' });
      if (slowDownOnce) { slowDownOnce = false; return send(400, { error: 'slow_down' }); }
      const ok = b64url(crypto.createHash('sha256').update(String(body.code_verifier || '')).digest()) === d.challenge;
      if (!ok) return send(400, { error: 'invalid_grant', error_description: 'PKCE verification failed' });
      if (d.status === 'pending') return send(400, { error: 'authorization_pending' });
      if (d.status === 'denied') { devices.delete(body.device_code); return send(400, { error: 'access_denied' }); }
      if (d.status === 'expired') { devices.delete(body.device_code); return send(400, { error: 'expired_token' }); }
      devices.delete(body.device_code);                        // ONE-TIME delivery
      const access_token = 'fdt_' + b64url(crypto.randomBytes(32)); tokens.set(access_token, { name: d.name });
      return send(200, { access_token, token_type: 'bearer', account: { name: 'tester' } });
    }
    if (req.method === 'POST' && req.url === '/api/device/revoke') {
      const t = (req.headers.authorization || '').replace(/^Bearer /, ''); const had = tokens.delete(t); return send(had ? 200 : 401, { ok: had });
    }
    send(404, { error: 'not_found' });
  });
  return {
    log, tokens, devices,
    slowDownNext() { slowDownOnce = true; },
    approve(user_code) { const d = devices.get(byUser.get(user_code)); if (d) d.status = 'approved'; },   // what the logged-in website page does on "Approve"
    deny(user_code) { const d = devices.get(byUser.get(user_code)); if (d) d.status = 'denied'; },
    expire(user_code) { const d = devices.get(byUser.get(user_code)); if (d) d.status = 'expired'; },
    listen: () => new Promise(r => srv.listen(0, '127.0.0.1', () => { port = srv.address().port; r(`http://127.0.0.1:${port}`); })),
    close: () => new Promise(r => srv.close(r)),
  };
}
