// Logic test of desktop-main.cjs against a STUB electron (NOT a real Electron run; see selftest.cjs for that).
const Module = require("node:module"), path = require("node:path"), fs = require("node:fs"), os = require("node:os");
const root = path.join(__dirname, "..");
const results = []; const rec = (n, ok, d = "") => { results.push(!!ok); console.log((ok ? "PASS " : "FAIL ") + n + (d ? " :: " + String(d).slice(0, 160) : "")); };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "rfa-main-"));
const handlers = {}, wcEvents = {}, opened = [], spawned = []; let windowOpenHandler = null, readyCb = null, loadedFile = null, winOpts = null;
const EventEmitterLike = () => { const m = {}; return { on: (e, f) => { (m[e] = m[e] || []).push(f); }, once: (e, f) => { (m[e] = m[e] || []).push(f); }, emit: (e, ...a) => (m[e] || []).forEach(f => f(...a)), m }; };
const wcEm = EventEmitterLike(), winEm = EventEmitterLike();
const fakeElectron = {
  app: { requestSingleInstanceLock: () => true, on() {}, getPath: () => tmp, getAppPath: () => root, getVersion: () => require(path.join(root, "package.json")).version, isPackaged: false, setAppUserModelId() {}, whenReady: () => ({ then: f => { readyCb = f; return { catch() {} }; } }), quit() {}, exit() {} },
  BrowserWindow: function (o) { winOpts = o; this.webContents = { on: wcEm.on, send() {}, getURL: () => "file://x", setWindowOpenHandler: f => { windowOpenHandler = f; } }; this.once = winEm.once; this.on = winEm.on; this.show = () => {}; this.isDestroyed = () => false; this.loadFile = async p => { loadedFile = p; }; },
  ipcMain: { handle: (n, f) => { handlers[n] = f; } },
  session: { defaultSession: { setPermissionRequestHandler() {} } },
  dialog: { showErrorBox() {} },
  shell: { openExternal: async u => { opened.push(u); } },
  safeStorage: { isEncryptionAvailable: () => true, encryptString: s => Buffer.from("ENC:" + s), decryptString: b => String(b).replace(/^ENC:/, "") },
};
fakeElectron.BrowserWindow.prototype.show = function () {};
const origLoad = Module._load;
Module._load = function (req, parent, ...r) {
  if (req === "electron") return fakeElectron;
  if (req === "node:child_process") return { spawn: (...a) => { spawned.push(a); const em = EventEmitterLike(); return { killed: false, stdin: { writable: true, write() {} }, stdout: { on() {} }, stderr: { on() {} }, on: em.on, kill() {} }; } };
  return origLoad.call(this, req, parent, ...r);
};
process.resourcesPath = tmp; fs.writeFileSync(path.join(tmp, "bridge.cjs"), "//stub");
const realFetch = globalThis.fetch; const fetched = [];
globalThis.fetch = async (u, o) => { fetched.push([String(u), o]); if (String(u).endsWith("/api/device/start")) return { ok: true, status: 200, json: async () => ({ device_code: "DC", user_code: "ABCD-EFGH", verification_uri_complete: "https://roblox-forge-ai.hatchable.site/device?user_code=ABCD-EFGH", expires_in: 600, interval: 5 }) }; return { ok: true, status: 200, json: async () => ({ logs: [{ event: "e" }] }) }; };
require(path.join(root, "desktop-main.cjs"));

(async () => {
  await readyCb();
  const APP = require("node:url").pathToFileURL(path.join(root, "desktop.html")).href;
  const ev = (url) => ({ senderFrame: { url } });
  rec("loads local desktop.html via loadFile (not a URL)", loadedFile === path.join(root, "desktop.html") && !/^https?:/.test(String(loadedFile)), loadedFile);
  rec("window: contextIsolation on, nodeIntegration off, sandbox on", winOpts.webPreferences.contextIsolation === true && winOpts.webPreferences.nodeIntegration === false && winOpts.webPreferences.sandbox === true);
  const expected = ["bridge-start", "bridge-send", "bridge-stop", "bridge-status", "forge-create-key", "app-info", "auth-start", "auth-cancel", "auth-status", "auth-logout", "forge-activity"];
  rec("all IPC channels registered", expected.every(n => handlers[n]), expected.filter(n => !handlers[n]).join());
  const notRejected = [];
  for (const n of expected) { let threw = false; try { await handlers[n](ev("https://roblox-forge-ai.hatchable.site/"), {}); } catch (e) { threw = /Untrusted/.test(e.message); } if (!threw) notRejected.push(n); }
  rec("every IPC channel rejects a renderer at the website origin", notRejected.length === 0, notRejected.join());
  let t2 = false; try { await handlers["app-info"](ev("file:///C:/evil/desktop.html")); } catch (e) { t2 = /Untrusted/.test(e.message); } rec("IPC rejects other local file:// page", t2);
  const info = await handlers["app-info"](ev(APP)); rec("app-info from our desktop.html works, version matches package.json", info.version === require(path.join(root, "package.json")).version, JSON.stringify(info));
  // navigation lock
  const mkNav = () => { let prevented = false; return { e: { preventDefault: () => { prevented = true; } }, was: () => prevented }; };
  let n1 = mkNav(); (wcEm.m["will-navigate"] || []).forEach(f => f(n1.e, "https://roblox-forge-ai.hatchable.site/")); rec("will-navigate to website is PREVENTED", n1.was());
  let n2 = mkNav(); (wcEm.m["will-redirect"] || []).forEach(f => f(n2.e, "https://roblox-forge-ai.hatchable.site/dashboard")); rec("will-redirect to website is PREVENTED", n2.was());
  let n3 = mkNav(); (wcEm.m["will-navigate"] || []).forEach(f => f(n3.e, APP)); rec("navigating to own desktop.html allowed", !n3.was());
  rec("window.open denied", windowOpenHandler({ url: "https://evil.example/" }).action === "deny" && !opened.some(u => /evil/.test(u)));
  windowOpenHandler({ url: "https://roblox-forge-ai.hatchable.site/device?user_code=AB" }); rec("window.open of Forge /device goes to system browser only", opened.length === 1 && /\/device/.test(opened[0]));
  // auth through IPC
  const r = await handlers["auth-start"](ev(APP)); rec("auth-start via IPC ok", r.ok && r.user_code === "ABCD-EFGH", JSON.stringify(r));
  rec("system browser opened on Forge origin with only user_code", opened.length === 2 && opened[1] === "https://roblox-forge-ai.hatchable.site/device?user_code=ABCD-EFGH", opened[1]);
  await handlers["auth-cancel"](ev(APP));
  // bridge uses device token when no manual key
  const authFile = path.join(tmp, "device-auth.bin"); fs.writeFileSync(authFile, fakeElectron.safeStorage.encryptString("fdt_TESTTOKEN"));
  await handlers["bridge-start"](ev(APP), { forgeKey: "", noxeryKey: "nox", autoDev: false });
  rec("bridge started with device token (from safeStorage) as Forge key", spawned.length === 1 && spawned[0][1][1] === "fdt_TESTTOKEN", JSON.stringify(spawned[0] && spawned[0][1]));
  const act = await handlers["forge-activity"](ev(APP), ""); const af = fetched.find(f => f[0].endsWith("/api/activity"));
  rec("activity fetched in MAIN process with x-forge-key header (no CORS from file://)", act.logs.length === 1 && af[1].headers["x-forge-key"] === "fdt_TESTTOKEN");
  globalThis.fetch = realFetch;
  const bad = results.filter(x => !x).length; console.log(`\n${results.length - bad}/${results.length} passed`); process.exit(bad ? 1 : 0);
})().catch(e => { console.error("HARNESS ERROR", e); process.exit(3); });
