// Real-Chromium UI regression test (Playwright). Loads desktop.html over file:// exactly like Electron's loadFile,
// with a mocked preload API. Usage: node tests/ui.test.mjs   (needs `playwright` + a Chromium; set CHROMIUM=/path if needed)
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const require = createRequire(process.env.PW_MODULES || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const here = path.dirname(fileURLToPath(import.meta.url));
const htmlUrl = pathToFileURL(path.join(here, '..', 'desktop.html')).href;
const results = []; const rec = (n, ok, d = '') => { results.push({ n, ok: !!ok, d: String(d) }); console.log((ok ? 'PASS ' : 'FAIL ') + n + (d ? '  :: ' + d : '')); };

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
const page = await browser.newPage({ viewport: { width: 1440, height: 920 } });
const errors = [], failedReqs = [], calls = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
page.on('requestfailed', r => failedReqs.push(r.url()));
page.on('request', r => { if (/^https?:/.test(r.url())) calls.push(r.url()); });
await page.exposeFunction('__rec', (n, a) => calls.push('IPC ' + n + ' ' + JSON.stringify(a)));
await page.addInitScript(() => {
  const listeners = []; window.__authListener = null;
  window.robloxForgeDesktop = {
    isDesktop: true,
    start: async (...a) => { __rec('start', a); return { ok: true }; },
    send: async (p) => { __rec('send', [p]); return { ok: true }; },
    stop: async () => { __rec('stop', []); return { ok: true }; },
    status: async () => ({ state: 'online', alive: true }),
    createKey: async () => ({ ok: true, key: 'forge_test' }),
    appInfo: async () => ({ version: '2.0.54', electron: '44.4.3', url: location.href, signedIn: false }),
    authStart: async () => { __rec('authStart', []); setTimeout(() => window.__emit({ type: 'auth', state: 'pending', detail: 'Tarayıcıda giriş yapıp cihazı onaylayın.', user_code: 'ABCD-EFGH' }), 20); return { ok: true, user_code: 'ABCD-EFGH' }; },
    authCancel: async () => { window.__emit({ type: 'auth', state: 'signed_out', detail: 'İptal edildi.' }); return { ok: true }; },
    authStatus: async () => ({ state: 'signed_out' }),
    authLogout: async () => { window.__emit({ type: 'auth', state: 'signed_out', detail: 'Çıkış yapıldı.' }); return { ok: true }; },
    activity: async () => ({ logs: [] }),
    onEvent: cb => { window.__emit = cb; },
  };
  // event recorder for hover/pointer/focus separation
  window.__ev = [];
  for (const t of ['pointerover', 'pointerenter', 'pointerdown', 'pointerup', 'click', 'focusin', 'focusout', 'mouseenter', 'mouseleave'])
    document.addEventListener(t, e => { const b = e.target.closest && e.target.closest('[data-nav]'); if (b) window.__ev.push(t + ':' + b.dataset.nav); }, true);
});
await page.goto(htmlUrl); await page.waitForTimeout(300);
const st = () => page.evaluate(() => ({ active: [...document.querySelectorAll('[data-nav].active')].map(b => b.dataset.nav), page: document.body.dataset.page, h1: (document.querySelector('#content h1') || {}).textContent || '' }));

rec('loads via file:// (not http)', page.url().startsWith('file://') && page.url().endsWith('desktop.html'), page.url());
rec('starts on dashboard, content rendered', (await st()).active.join() === 'dashboard' && (await st()).h1.length > 0);
rec('version shown in sidebar', /v2\.0\.54/.test(await page.textContent('#sideVer')));

// overlay / pointer-events: elementFromPoint at every interactive element
const navs = await page.$$eval('[data-nav]', b => b.map(x => x.dataset.nav));
rec('6 nav buttons', navs.length === 6, navs.join());
for (const n of navs) {
  const ok = await page.evaluate(n => { const b = document.querySelector(`[data-nav="${n}"]`), r = b.getBoundingClientRect(), t = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2); return t === b || b.contains(t); }, n);
  rec('no invisible overlay over nav:' + n, ok);
}
rec('no fullscreen fixed/absolute overlay', await page.evaluate(() => ![...document.querySelectorAll('body *')].some(e => { const c = getComputedStyle(e); const r = e.getBoundingClientRect(); return (c.position === 'fixed') && r.width >= innerWidth * .9 && r.height >= innerHeight * .9 && c.pointerEvents !== 'none'; })));

// sequential real mouse clicks, every button, exactly one blue afterwards
const seen = new Set();
for (const n of ['chat', 'studio', 'plan', 'logs', 'keys', 'dashboard']) {
  await page.click(`[data-nav="${n}"]`); const s = await st(); seen.add(s.h1);
  rec(`click ${n}: page changes, exactly one active (no stale blue)`, s.active.length === 1 && s.active[0] === n && s.page === n && s.h1.length > 0, JSON.stringify(s));
}
rec('pages have distinct content', seen.size >= 5, [...seen].join(' | '));
// computed style: only the active one is blue
await page.click('[data-nav="keys"]'); await page.mouse.move(700, 500);
const bg = await page.$$eval('[data-nav]', b => b.map(x => [x.dataset.nav, getComputedStyle(x).backgroundColor]));
const blue = bg.filter(([, c]) => c === 'rgb(238, 242, 255)').map(([n]) => n);
rec('computed style: only "keys" has active background after moving away', blue.join() === 'keys', JSON.stringify(bg));

// hover / pointerdown / pointerup / click / focus, separately
await page.evaluate(() => window.__ev.length = 0);
await page.hover('[data-nav="plan"]');
let ev = await page.evaluate(() => window.__ev.slice());
rec('hover fires pointerover/enter but NOT click and does not navigate', ev.some(e => e.startsWith('pointerover')) && !ev.some(e => e.startsWith('click')) && (await st()).page === 'keys', ev.join());
const hb = await page.$eval('[data-nav="plan"]', b => getComputedStyle(b).backgroundColor);
rec('hover style differs from active style', hb !== 'rgb(238, 242, 255)' && hb === 'rgb(245, 247, 255)', hb);
await page.evaluate(() => window.__ev.length = 0);
await page.mouse.down(); ev = await page.evaluate(() => window.__ev.slice());
rec('pointerdown alone does not navigate', ev.some(e => e.startsWith('pointerdown')) && (await st()).page === 'keys', ev.join());
await page.mouse.up(); await page.waitForTimeout(50); ev = await page.evaluate(() => window.__ev.slice());
rec('pointerup+click navigates exactly once', (await st()).page === 'plan' && ev.filter(e => e.startsWith('click')).length === 1, ev.join());
await page.mouse.move(700, 500);
rec('no focus-ring/blue residue after mouse click (focus-visible not matched)', await page.$eval('[data-nav="plan"]', b => !b.matches(':focus-visible')));
// keyboard focus
await page.focus('[data-nav="studio"]'); await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab');
rec('keyboard focus works and Enter navigates', await (async () => { await page.focus('[data-nav="studio"]'); await page.keyboard.press('Enter'); return (await st()).page === 'studio'; })());
await page.keyboard.press('Space'); rec('Space on focused nav button keeps single active', (await st()).active.length === 1);

// rapid / storm clicks
const seq = ['keys', 'chat', 'logs', 'dashboard', 'plan', 'studio', 'keys', 'dashboard', 'chat', 'chat', 'chat', 'logs', 'dashboard', 'keys', 'dashboard'];
for (const n of seq) await page.click(`[data-nav="${n}"]`, { delay: 0 });
let s = await st(); rec('15 rapid clicks: final = dashboard, one active', s.active.length === 1 && s.active[0] === 'dashboard' && s.h1.length > 0, JSON.stringify(s));
// truly concurrent (no awaiting render) via real mouse
const box = async n => (await page.$(`[data-nav="${n}"]`)).boundingBox();
for (const n of ['chat', 'logs', 'keys', 'plan', 'dashboard', 'chat']) { const b = await box(n); await page.mouse.click(b.x + 20, b.y + 10); }
s = await st(); rec('back-to-back mouse.click storm ends consistent (chat)', s.active.join() === 'chat' && s.page === 'chat', JSON.stringify(s));
await page.click('[data-nav="dashboard"]', { clickCount: 3 }); s = await st();
rec('triple/dbl click does not break state', s.active.join() === 'dashboard');

// logs stale-async: leave page while activity is pending
await page.evaluate(() => { window.robloxForgeDesktop.activity = () => new Promise(r => setTimeout(() => r({ logs: [{ created_at: Date.now(), level: 'info', event: 'X' }] }), 300)); });
await page.click('[data-nav="logs"]'); await page.click('[data-nav="chat"]'); await page.waitForTimeout(450);
s = await st(); rec('slow Logs response does not clobber page after navigating away', s.page === 'chat' && s.h1 === 'GPT-6 ASTRA', JSON.stringify(s));

// dashboard: cards, send, chat
await page.click('[data-nav="dashboard"]'); await page.click('[data-action="scan"]');
rec('dashboard card triggers D.send', calls.some(c => c.startsWith('IPC send') && /Studioyu önce tara/.test(c)));
await page.click('[data-nav="chat"]'); await page.fill('#prompt', 'merhaba'); await page.press('#prompt', 'Enter');
rec('chat Enter sends and echoes user msg', calls.some(c => c.includes('merhaba')) && /merhaba/.test(await page.textContent('#messages')));
await page.fill('#prompt', 'btn'); await page.click('[data-action="send"]'); rec('chat Gönder button sends', calls.some(c => c.includes('"btn"')));

// API keys
await page.click('[data-nav="keys"]');
rec('API Keys: inputs typeable (no overlay)', await (async () => { await page.fill('#nox', 'nox-123'); await page.fill('#forge', 'f-1'); return (await page.inputValue('#nox')) === 'nox-123'; })());
await page.click('[data-action="make-key"]'); await page.waitForTimeout(50);
rec('Yeni Forge API Key Oluştur works', (await page.inputValue('#forge')) === 'forge_test');
await page.click('[data-action="save-key"]'); await page.waitForTimeout(50);
rec('Kaydet & Bağlan calls start with keys', calls.some(c => c.startsWith('IPC start') && c.includes('nox-123')));
// studio page buttons
await page.click('[data-nav="studio"]'); await page.click('[data-action="connect"]'); await page.click('[data-action="stop"]'); await page.click('[data-action="scan"]');
rec('Studio page buttons work', calls.some(c => c.startsWith('IPC stop')));
// plan
await page.click('[data-nav="plan"]'); await page.fill('#brief', 'anime battleground'); await page.click('[data-action="make-plan"]');
rec('AAA Planner sends brief', calls.some(c => c.includes('anime battleground')));

// Auto Development: button + checkbox (dashboard and chat)
await page.evaluate(() => { localStorage.setItem('noxeryKey', 'n'); localStorage.removeItem('autoDev'); });
await page.click('[data-nav="dashboard"]');
await page.click('#autoToggle'); await page.waitForTimeout(700);
rec('Auto Dev button OFF->ON (text + storage)', (await page.textContent('#autoToggle')) === 'AUTO DEV: ON' && (await page.evaluate(() => localStorage.getItem('autoDev'))) === '1');
rec('Auto Dev checkbox reflects ON', await page.isChecked('#chatAuto'));
await page.click('.autoSwitch'); await page.waitForTimeout(700);
rec('Auto Dev switch (label click) ON->OFF, button text follows', !(await page.isChecked('#chatAuto')) && (await page.textContent('#autoToggle')) === 'AUTO DEV: OFF');
const startsBefore = calls.filter(c => c.startsWith('IPC start')).length;
await page.evaluate(() => localStorage.setItem('autoDev', '0'));
for (let i = 0; i < 6; i++) await page.click('#autoToggle', { delay: 0 });
await page.waitForTimeout(3500);
const fin = await page.evaluate(() => localStorage.getItem('autoDev')), txt = await page.textContent('#autoToggle');
rec('Auto Dev rapid x6 toggles: final state consistent (even => OFF)', fin === '0' && txt === 'AUTO DEV: OFF', `storage=${fin} text=${txt}`);
const starts = calls.filter(c => c.startsWith('IPC start')).length - startsBefore;
rec('Auto Dev: exactly one start() per toggle (no duplicate handler)', starts === 6, 'starts=' + starts);
await page.click('[data-nav="chat"]'); await page.click('.autoSwitch'); await page.waitForTimeout(600);
rec('Auto Dev on Chat page works', (await page.evaluate(() => localStorage.getItem('autoDev'))) === '1');

// Website login UI
await page.click('[data-nav="keys"]'); await page.click('#loginBtn2'); await page.waitForTimeout(150);
rec('Login: shows pending + code, no secrets', /ABCD-EFGH/.test(await page.textContent('#authText')) && (await page.textContent('#sideAuth')).includes('onay'));
rec('Login: cancel button visible', await page.isVisible('#loginCancel'));
await page.click('#loginCancel'); await page.waitForTimeout(100);
rec('Login: cancel returns to signed-out', (await page.textContent('#sideAuth')).includes('kapalı'));
await page.evaluate(() => window.__emit({ type: 'auth', state: 'approved', detail: 'Giriş başarılı.' })); await page.waitForTimeout(80);
rec('Login: approved -> logout visible, header shows Çıkış', await page.isVisible('#logoutBtn') && (await page.textContent('#loginBtn')) === 'Çıkış');

// bridge events update UI
await page.evaluate(() => window.__emit({ type: 'state', state: 'online', detail: '' }));
rec('bridge state event updates status pill', (await page.textContent('#status')) === 'ONLINE');

// network / redirect / CSP
rec('no http(s) requests made by renderer during test', calls.filter(c => /^https?:/.test(c)).length === 0, calls.filter(c => /^https?:/.test(c)).join());
rec('no failed requests', failedReqs.length === 0, failedReqs.join());
rec('no JS/console errors during whole run', errors.length === 0, errors.join(' | '));
const csp = await page.$eval('meta[http-equiv="Content-Security-Policy"]', m => m.content);
rec('CSP present, script-src self, no unsafe-eval/inline scripts', /script-src 'self'/.test(csp) && !/unsafe-eval/.test(csp) && !/script-src[^;]*unsafe-inline/.test(csp), csp);
const inj = await page.evaluate(() => { const s = document.createElement('script'); s.textContent = 'window.__pwn=1'; document.body.appendChild(s); return !!window.__pwn; });
rec('CSP blocks injected inline script', inj === false);
await browser.close();
const bad = results.filter(r => !r.ok); console.log(`\n${results.length - bad.length}/${results.length} passed`); process.exit(bad.length ? 1 : 0);
